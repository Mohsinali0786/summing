pub fn sum (nm1:u8,nm2:u8)->u8
{
    nm1+nm2
}